Hello,

Thank for downloading JUST SIGNATURE.

NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/RianRahardi

Link to purchase full version and commercial license: 
https://crmrkt.com/NW1QBp

Please visit our store for more great fonts : 
https://creativemarket.com/creatype

And follow my instagram for update : @creatypestudio

If there is a problem, question, or anything about my fonts, please sent an email to

pinegraphdsgn@gmail.com

How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,


Creatype Studio