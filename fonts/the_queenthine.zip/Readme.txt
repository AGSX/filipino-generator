NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated, your donation will help us  to create more fonts

Paypal account for donation : https://www.paypal.me/Davidkasidi

Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/the-queenthine/

https://graphicriver.net/item/the-queenthine/22785932

..... 

check here, 45% discount, hurry up
start : 12.00 PM 8th Nov
end   : 12.00 PM 28th Nov

https://fontbundles.net/silverdav/159119-the-queenthine

.........

Please visit our store for more great fonts :
https://www.creativefabrica.com/designer/silverdav/
https://graphicriver.net/user/rudisprod
https://fontbundles.net/silverdav


More Info Contact:
davidkasidi949@gmail.com
Thank you.